import unittest
from grade_calculator import calculate_result
from student_records import add_student, search_student, remove_student
from number_analysis import analyze_numbers


class GradeCalculatorTests(unittest.TestCase):
    def test_grade_a(self):
        self.assertEqual(calculate_result("Asha", [90, 90, 90])["grade"], "A")

    def test_grade_b(self):
        self.assertEqual(calculate_result("Asha", [75, 75, 75])["grade"], "B")

    def test_invalid_marks(self):
        with self.assertRaises(ValueError):
            calculate_result("Asha", [101, 70, 80])


class StudentRecordTests(unittest.TestCase):
    def test_add_search_remove(self):
        students = []
        add_student(students, "Meghana")
        self.assertEqual(search_student(students, "meghana"), "Meghana")
        self.assertTrue(remove_student(students, "MEGHANA"))
        self.assertEqual(students, [])

    def test_duplicate_student(self):
        students = ["Meghana"]
        with self.assertRaises(ValueError):
            add_student(students, "meghana")


class NumberAnalysisTests(unittest.TestCase):
    def test_analysis(self):
        result = analyze_numbers([2, 4, 6])
        self.assertEqual(result["largest"], 6)
        self.assertEqual(result["smallest"], 2)
        self.assertEqual(result["average"], 4)

    def test_empty_list(self):
        with self.assertRaises(ValueError):
            analyze_numbers([])


if __name__ == "__main__":
    unittest.main()
